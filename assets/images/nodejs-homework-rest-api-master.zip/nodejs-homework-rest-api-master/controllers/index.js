const contacts = require('./contacts');
const users = require('./auth');

module.exports = {
    contacts,
    users,
};
