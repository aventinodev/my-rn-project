const addContactSchema = require('./addContacts');
const updateContactSchema = require('./updateContacts');
const updateStatusContactSchema = require('./updateStatusContact');

module.exports = {
    addContactSchema,
    updateContactSchema,
    updateStatusContactSchema,
};
